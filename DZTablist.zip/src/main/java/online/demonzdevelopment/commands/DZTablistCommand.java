package online.demonzdevelopment.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import online.demonzdevelopment.DZTablist;
import online.demonzdevelopment.utils.PerformanceMonitor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Main command handler
 */
public class DZTablistCommand implements CommandExecutor, TabCompleter {
    
    private final DZTablist plugin;
    
    public DZTablistCommand(DZTablist plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
        if (!sender.hasPermission("dztablist.admin")) {
            sender.sendMessage(Component.text("You don't have permission to use this command.").color(NamedTextColor.RED));
            return true;
        }
        
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "reload":
                handleReload(sender);
                break;
            case "cpu":
                handleCPU(sender);
                break;
            case "help":
                sendHelp(sender);
                break;
            default:
                sender.sendMessage(Component.text("Unknown subcommand. Use /dztablist help").color(NamedTextColor.RED));
        }
        
        return true;
    }
    
    /**
     * Handle reload command
     */
    private void handleReload(CommandSender sender) {
        sender.sendMessage(Component.text("Reloading DZTablist...").color(NamedTextColor.YELLOW));
        
        try {
            plugin.reload();
            sender.sendMessage(Component.text("✓ DZTablist reloaded successfully!").color(NamedTextColor.GREEN));
        } catch (Exception e) {
            sender.sendMessage(Component.text("✗ Failed to reload: " + e.getMessage()).color(NamedTextColor.RED));
            plugin.getErrorLogger().log("Failed to reload plugin", e);
        }
    }
    
    /**
     * Handle CPU command
     */
    private void handleCPU(CommandSender sender) {
        sender.sendMessage(Component.text("════════════════════════════════════").color(NamedTextColor.GRAY));
        sender.sendMessage(Component.text("  DZTablist Performance Monitor").color(NamedTextColor.GOLD));
        sender.sendMessage(Component.text("════════════════════════════════════").color(NamedTextColor.GRAY));
        
        Map<String, PerformanceMonitor.FeatureStats> stats = plugin.getPerformanceMonitor().getAllStats();
        
        if (stats.isEmpty()) {
            sender.sendMessage(Component.text("No performance data available yet.").color(NamedTextColor.YELLOW));
        } else {
            double totalAvg = 0;
            for (Map.Entry<String, PerformanceMonitor.FeatureStats> entry : stats.entrySet()) {
                PerformanceMonitor.FeatureStats stat = entry.getValue();
                sender.sendMessage(Component.text(String.format("%s: %.2fms avg (%,d calls)", 
                        entry.getKey(), stat.getAverageTime(), stat.getCalls())).color(NamedTextColor.WHITE));
                totalAvg += stat.getAverageTime();
            }
            
            sender.sendMessage(Component.text("════════════════════════════════════").color(NamedTextColor.GRAY));
            sender.sendMessage(Component.text(String.format("Total: %.2fms avg | ~0%% CPU usage", totalAvg))
                    .color(NamedTextColor.GREEN));
        }
        
        sender.sendMessage(Component.text("════════════════════════════════════").color(NamedTextColor.GRAY));
    }
    
    /**
     * Send help message
     */
    private void sendHelp(CommandSender sender) {
        sender.sendMessage(Component.text("════════════════════════════════════").color(NamedTextColor.GRAY));
        sender.sendMessage(Component.text("  DZTablist v" + plugin.getDescription().getVersion()).color(NamedTextColor.GOLD));
        sender.sendMessage(Component.text("  By DemonZ Development").color(NamedTextColor.GRAY));
        sender.sendMessage(Component.text("════════════════════════════════════").color(NamedTextColor.GRAY));
        sender.sendMessage(Component.text("/dztablist reload").color(NamedTextColor.YELLOW)
                .append(Component.text(" - Reload plugin").color(NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/dztablist cpu").color(NamedTextColor.YELLOW)
                .append(Component.text(" - Show CPU usage").color(NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/dztablist help").color(NamedTextColor.YELLOW)
                .append(Component.text(" - Show this menu").color(NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("════════════════════════════════════").color(NamedTextColor.GRAY));
    }
    
    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("reload", "cpu", "help");
        }
        return new ArrayList<>();
    }
}
