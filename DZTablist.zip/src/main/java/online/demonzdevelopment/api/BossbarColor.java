package online.demonzdevelopment.api;

/**
 * Bossbar colors
 */
public enum BossbarColor {
    PINK,
    BLUE,
    RED,
    GREEN,
    YELLOW,
    PURPLE,
    WHITE
}
