package online.demonzdevelopment.api;

/**
 * Bossbar styles
 */
public enum BossbarStyle {
    SOLID,
    SEGMENTED_6,
    SEGMENTED_10,
    SEGMENTED_12,
    SEGMENTED_20
}
