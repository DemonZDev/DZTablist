package online.demonzdevelopment.api;

/**
 * Nametag visibility options
 */
public enum NameTagVisibility {
    ALWAYS,
    NEVER,
    HIDE_FOR_OTHER_TEAMS,
    HIDE_FOR_OWN_TEAM
}
