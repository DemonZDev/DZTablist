package online.demonzdevelopment.api;

/**
 * Collision rules for nametags
 */
public enum CollisionRule {
    ALWAYS,
    NEVER,
    PUSH_OWN_TEAM,
    PUSH_OTHER_TEAMS
}
